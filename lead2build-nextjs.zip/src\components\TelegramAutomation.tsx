'use client'

import { useState } from 'react'
import { Zap, Clock, Users, AlertTriangle, CheckCircle, Settings, Bot } from 'lucide-react'

interface AutomationRule {
  id: string
  name: string
  trigger: 'stage_change' | 'deadline_approaching' | 'voting_started' | 'document_ready' | 'inspection_complete'
  conditions: {
    stage?: string
    daysBeforeDeadline?: number
    targetRole?: 'all' | 'residents' | 'managers'
    address?: string
  }
  telegramTemplate: string
  enabled: boolean
  lastTriggered?: Date
  triggerCount: number
}

export default function TelegramAutomation() {
  const [rules, setRules] = useState<AutomationRule[]>([
    {
      id: '1',
      name: 'Напоминание о приближающемся дедлайне',
      trigger: 'deadline_approaching',
      conditions: {
        daysBeforeDeadline: 3,
        targetRole: 'residents'
      },
      telegramTemplate: '⚠️ Внимание! До истечения срока {task} по адресу {address} остается {days} дней.',
      enabled: true,
      triggerCount: 15
    },
    {
      id: '2',
      name: 'Уведомление о начале голосования',
      trigger: 'voting_started',
      conditions: {
        targetRole: 'all'
      },
      telegramTemplate: '🗳️ Началось голосование по адресу {address}. Тема: {topic}. Время: {time}',
      enabled: true,
      lastTriggered: new Date(2025, 8, 20),
      triggerCount: 8
    },
    {
      id: '3',
      name: 'Готовность документов',
      trigger: 'document_ready',
      conditions: {
        targetRole: 'managers'
      },
      telegramTemplate: '📋 Документы готовы к проверке по адресу {address}. Этап: {stage}',
      enabled: true,
      triggerCount: 12
    },
    {
      id: '4',
      name: 'Завершение обследования',
      trigger: 'inspection_complete',
      conditions: {
        targetRole: 'all'
      },
      telegramTemplate: '✅ Техническое обследование по адресу {address} завершено. Результат: {result}',
      enabled: false,
      triggerCount: 5
    }
  ])

  const [showAddForm, setShowAddForm] = useState(false)
  const [newRule, setNewRule] = useState<Partial<AutomationRule>>({
    name: '',
    trigger: 'deadline_approaching',
    conditions: { targetRole: 'all' },
    telegramTemplate: '',
    enabled: true
  })

  const triggers = [
    { value: 'stage_change', label: 'Изменение этапа', icon: '🔄' },
    { value: 'deadline_approaching', label: 'Приближение дедлайна', icon: '⏰' },
    { value: 'voting_started', label: 'Начало голосования', icon: '🗳️' },
    { value: 'document_ready', label: 'Готовность документов', icon: '📋' },
    { value: 'inspection_complete', label: 'Завершение обследования', icon: '✅' }
  ]

  const targetRoles = [
    { value: 'all', label: 'Все пользователи' },
    { value: 'residents', label: 'Только жильцы' },
    { value: 'managers', label: 'Только управляющие' }
  ]

  const addRule = () => {
    if (newRule.name && newRule.telegramTemplate) {
      const rule: AutomationRule = {
        id: Date.now().toString(),
        name: newRule.name,
        trigger: newRule.trigger || 'deadline_approaching',
        conditions: newRule.conditions || { targetRole: 'all' },
        telegramTemplate: newRule.telegramTemplate,
        enabled: newRule.enabled || true,
        triggerCount: 0
      }
      setRules([...rules, rule])
      setNewRule({
        name: '',
        trigger: 'deadline_approaching',
        conditions: { targetRole: 'all' },
        telegramTemplate: '',
        enabled: true
      })
      setShowAddForm(false)
    }
  }

  const toggleRule = (id: string) => {
    setRules(prev => 
      prev.map(rule => 
        rule.id === id ? { ...rule, enabled: !rule.enabled } : rule
      )
    )
  }

  const deleteRule = (id: string) => {
    setRules(prev => prev.filter(rule => rule.id !== id))
  }

  const testRule = async (rule: AutomationRule) => {
    // Имитация тестовой отправки
    alert(`Тестовое уведомление отправлено!\n\nПравило: ${rule.name}\nСообщение: ${rule.telegramTemplate}`)
  }

  const getTriggerIcon = (trigger: AutomationRule['trigger']) => {
    const found = triggers.find(t => t.value === trigger)
    return found ? found.icon : '⚡'
  }

  const getTriggerLabel = (trigger: AutomationRule['trigger']) => {
    const found = triggers.find(t => t.value === trigger)
    return found ? found.label : trigger
  }

  return (
    <div className="bg-white rounded-lg shadow">
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Zap className="h-6 w-6 text-yellow-600" />
            <h2 className="text-xl font-semibold text-gray-900">Автоматизация Telegram</h2>
            <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full">
              {rules.filter(r => r.enabled).length} активных
            </span>
          </div>
          <button
            onClick={() => setShowAddForm(true)}
            className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 flex items-center space-x-2"
          >
            <Zap className="h-4 w-4" />
            <span>Добавить правило</span>
          </button>
        </div>
      </div>

      {/* Форма добавления правила */}
      {showAddForm && (
        <div className="p-6 border-b border-gray-200 bg-gray-50">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Новое правило автоматизации</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Название правила
              </label>
              <input
                type="text"
                value={newRule.name}
                onChange={(e) => setNewRule({...newRule, name: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
                placeholder="Введите название правила"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Триггер
              </label>
              <select
                value={newRule.trigger}
                onChange={(e) => setNewRule({...newRule, trigger: e.target.value as any})}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
              >
                {triggers.map(trigger => (
                  <option key={trigger.value} value={trigger.value}>
                    {trigger.icon} {trigger.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Целевая аудитория
              </label>
              <select
                value={newRule.conditions?.targetRole}
                onChange={(e) => setNewRule({
                  ...newRule, 
                  conditions: { ...newRule.conditions, targetRole: e.target.value as any }
                })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
              >
                {targetRoles.map(role => (
                  <option key={role.value} value={role.value}>
                    {role.label}
                  </option>
                ))}
              </select>
            </div>

            {newRule.trigger === 'deadline_approaching' && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Дней до дедлайна
                </label>
                <input
                  type="number"
                  min="1"
                  max="30"
                  value={newRule.conditions?.daysBeforeDeadline || 3}
                  onChange={(e) => setNewRule({
                    ...newRule,
                    conditions: { ...newRule.conditions, daysBeforeDeadline: parseInt(e.target.value) }
                  })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
                />
              </div>
            )}
          </div>

          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Шаблон сообщения
            </label>
            <textarea
              value={newRule.telegramTemplate}
              onChange={(e) => setNewRule({...newRule, telegramTemplate: e.target.value})}
              rows={3}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
              placeholder="Используйте переменные: {address}, {task}, {days}, {topic}, {time}, {stage}, {result}"
            />
            <p className="text-xs text-gray-500 mt-1">
              Доступные переменные: {'{address}'}, {'{task}'}, {'{days}'}, {'{topic}'}, {'{time}'}, {'{stage}'}, {'{result}'}
            </p>
          </div>

          <div className="flex justify-end space-x-3">
            <button
              onClick={() => setShowAddForm(false)}
              className="px-4 py-2 text-gray-600 hover:text-gray-800"
            >
              Отмена
            </button>
            <button
              onClick={addRule}
              className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700"
            >
              Сохранить правило
            </button>
          </div>
        </div>
      )}

      {/* Список правил */}
      <div className="divide-y divide-gray-200">
        {rules.map((rule) => (
          <div key={rule.id} className="p-6">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="flex items-center space-x-3 mb-2">
                  <span className="text-2xl">{getTriggerIcon(rule.trigger)}</span>
                  <h3 className="text-lg font-medium text-gray-900">{rule.name}</h3>
                  <span className={`px-2 py-1 text-xs rounded-full ${
                    rule.enabled ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                  }`}>
                    {rule.enabled ? 'Активно' : 'Отключено'}
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4 text-sm">
                  <div>
                    <span className="text-gray-500">Триггер:</span>
                    <p className="font-medium text-gray-900">{getTriggerLabel(rule.trigger)}</p>
                  </div>
                  <div>
                    <span className="text-gray-500">Аудитория:</span>
                    <p className="font-medium text-gray-900">
                      {targetRoles.find(r => r.value === rule.conditions.targetRole)?.label}
                    </p>
                  </div>
                  <div>
                    <span className="text-gray-500">Срабатываний:</span>
                    <p className="font-medium text-gray-900">{rule.triggerCount}</p>
                  </div>
                </div>

                <div className="bg-gray-50 p-3 rounded-md mb-4">
                  <span className="text-sm text-gray-500">Шаблон сообщения:</span>
                  <p className="text-sm text-gray-700 mt-1">{rule.telegramTemplate}</p>
                </div>

                {rule.lastTriggered && (
                  <p className="text-xs text-gray-500">
                    Последнее срабатывание: {rule.lastTriggered.toLocaleString('ru-RU')}
                  </p>
                )}
              </div>

              <div className="flex items-center space-x-2 ml-4">
                <button
                  onClick={() => testRule(rule)}
                  className="p-2 text-blue-600 hover:bg-blue-50 rounded-md"
                  title="Тест правила"
                >
                  <Bot className="h-4 w-4" />
                </button>
                
                <button
                  onClick={() => toggleRule(rule.id)}
                  className={`p-2 rounded-md ${
                    rule.enabled 
                      ? 'text-red-600 hover:bg-red-50' 
                      : 'text-green-600 hover:bg-green-50'
                  }`}
                  title={rule.enabled ? 'Отключить' : 'Включить'}
                >
                  {rule.enabled ? <AlertTriangle className="h-4 w-4" /> : <CheckCircle className="h-4 w-4" />}
                </button>

                <button
                  onClick={() => deleteRule(rule.id)}
                  className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-md"
                  title="Удалить правило"
                >
                  <Settings className="h-4 w-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {rules.length === 0 && (
        <div className="p-8 text-center">
          <Zap className="h-12 w-12 text-gray-300 mx-auto mb-4" />
          <p className="text-gray-500">Нет настроенных правил автоматизации</p>
          <p className="text-sm text-gray-400">Добавьте правила для автоматической отправки уведомлений</p>
        </div>
      )}
    </div>
  )
}