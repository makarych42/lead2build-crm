'use client'

import { useState, useEffect } from 'react'
import { Vote, Users, Calendar, CheckCircle, XCircle, Clock, Plus, BarChart3 } from 'lucide-react'

interface Voting {
  id: string
  leadId: string
  address: string
  registryRequested?: string
  registryReceived?: string
  giszhkhRegistered?: string
  votingForm?: string
  votingStartDate?: string
  votingEndDate?: string
  requiredVotes?: number
  currentVotes: number
  votesPercent: number
  status: string
  failureReason?: string
}

export default function VotingManager() {
  const [votings, setVotings] = useState<Voting[]>([])
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState('overview')

  useEffect(() => {
    // Start with empty data - no test data
    setVotings([])
    setLoading(false)
  }, [])

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'PREPARATION':
        return 'bg-yellow-100 text-yellow-800'
      case 'ACTIVE':
        return 'bg-blue-100 text-blue-800'
      case 'COMPLETED':
        return 'bg-green-100 text-green-800'
      case 'FAILED':
        return 'bg-red-100 text-red-800'
      default:
        return 'bg-gray-100 text-gray-800'
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case 'PREPARATION':
        return 'Подготовка'
      case 'ACTIVE':
        return 'Активное'
      case 'COMPLETED':
        return 'Завершено'
      case 'FAILED':
        return 'Неудачное'
      default:
        return status
    }
  }

  const getVotingFormText = (form?: string) => {
    switch (form) {
      case 'MEETING':
        return 'Очное собрание'
      case 'ABSENTEE':
        return 'Заочное голосование'
      case 'MIXED':
        return 'Смешанная форма'
      default:
        return 'Не указано'
    }
  }

  const formatDate = (dateString?: string) => {
    if (!dateString) return 'Не установлено'
    return new Date(dateString).toLocaleDateString('ru-RU')
  }

  const getDaysRemaining = (endDate?: string) => {
    if (!endDate) return null
    const end = new Date(endDate)
    const now = new Date()
    const diffTime = end.getTime() - now.getTime()
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
    return diffDays > 0 ? diffDays : 0
  }

  const getOverallStats = () => {
    const total = votings.length
    const active = votings.filter(v => v.status === 'ACTIVE').length
    const completed = votings.filter(v => v.status === 'COMPLETED').length
    const successful = votings.filter(v => v.status === 'COMPLETED' && v.votesPercent >= 67).length
    const successRate = completed > 0 ? Math.round((successful / completed) * 100) : 0

    return { total, active, completed, successful, successRate }
  }

  const stats = getOverallStats()

  if (loading) {
    return (
      <div className="flex justify-center items-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
        <span className="ml-2 text-gray-600">Loading voting data...</span>
      </div>
    )
  }

  return (
    <div>
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-2">Voting Management</h2>
        <p className="text-gray-600">Organize and monitor voting processes for construction projects</p>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mb-8">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <div className="bg-blue-500 rounded-md p-3">
              <Vote className="h-6 w-6 text-white" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Total Votings</p>
              <p className="text-2xl font-semibold text-gray-900">{stats.total}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <div className="bg-yellow-500 rounded-md p-3">
              <Clock className="h-6 w-6 text-white" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Active</p>
              <p className="text-2xl font-semibold text-gray-900">{stats.active}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <div className="bg-green-500 rounded-md p-3">
              <CheckCircle className="h-6 w-6 text-white" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Completed</p>
              <p className="text-2xl font-semibold text-gray-900">{stats.completed}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <div className="bg-purple-500 rounded-md p-3">
              <Users className="h-6 w-6 text-white" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Successful</p>
              <p className="text-2xl font-semibold text-gray-900">{stats.successful}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <div className="bg-indigo-500 rounded-md p-3">
              <BarChart3 className="h-6 w-6 text-white" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Success Rate</p>
              <p className="text-2xl font-semibold text-gray-900">{stats.successRate}%</p>
            </div>
          </div>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="bg-white rounded-lg shadow mb-6">
        <div className="border-b border-gray-200">
          <nav className="-mb-px flex">
            <button
              onClick={() => setActiveTab('overview')}
              className={`py-2 px-4 border-b-2 font-medium text-sm ${
                activeTab === 'overview'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Overview
            </button>
            <button
              onClick={() => setActiveTab('active')}
              className={`py-2 px-4 border-b-2 font-medium text-sm ${
                activeTab === 'active'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Active Votings ({stats.active})
            </button>
            <button
              onClick={() => setActiveTab('completed')}
              className={`py-2 px-4 border-b-2 font-medium text-sm ${
                activeTab === 'completed'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Completed
            </button>
          </nav>
        </div>
      </div>

      {/* Voting Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {votings
          .filter(voting => {
            if (activeTab === 'active') return voting.status === 'ACTIVE'
            if (activeTab === 'completed') return voting.status === 'COMPLETED'
            return true
          })
          .map((voting) => {
            const daysRemaining = getDaysRemaining(voting.votingEndDate)
            const isSuccessful = voting.votesPercent >= 67

            return (
              <div key={voting.id} className="bg-white rounded-lg shadow p-6">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">{voting.address}</h3>
                    <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(voting.status)}`}>
                      {getStatusText(voting.status)}
                    </span>
                  </div>
                  {voting.status === 'COMPLETED' && (
                    <div className="flex items-center">
                      {isSuccessful ? (
                        <CheckCircle className="h-6 w-6 text-green-500" />
                      ) : (
                        <XCircle className="h-6 w-6 text-red-500" />
                      )}
                    </div>
                  )}
                </div>

                {/* Voting Progress */}
                <div className="mb-4">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm font-medium text-gray-700">Voting Progress</span>
                    <span className="text-sm text-gray-600">
                      {voting.currentVotes} / {voting.requiredVotes} votes ({voting.votesPercent}%)
                    </span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className={`h-2 rounded-full ${
                        voting.votesPercent >= 67 ? 'bg-green-500' : 'bg-blue-500'
                      }`}
                      style={{ width: `${Math.min(voting.votesPercent, 100)}%` }}
                    ></div>
                  </div>
                  <div className="flex justify-between text-xs text-gray-500 mt-1">
                    <span>0%</span>
                    <span className="text-red-600">67% required</span>
                    <span>100%</span>
                  </div>
                </div>

                {/* Voting Details */}
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Form:</span>
                    <span className="text-gray-900">{getVotingFormText(voting.votingForm)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Start Date:</span>
                    <span className="text-gray-900">{formatDate(voting.votingStartDate)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">End Date:</span>
                    <span className="text-gray-900">{formatDate(voting.votingEndDate)}</span>
                  </div>
                  {daysRemaining !== null && voting.status === 'ACTIVE' && (
                    <div className="flex justify-between">
                      <span className="text-gray-600">Days Remaining:</span>
                      <span className={`font-medium ${daysRemaining <= 3 ? 'text-red-600' : 'text-green-600'}`}>
                        {daysRemaining} days
                      </span>
                    </div>
                  )}
                </div>

                {/* Action Buttons */}
                <div className="mt-6 flex space-x-2">
                  <button className="flex-1 bg-blue-600 text-white px-3 py-2 rounded-md text-sm font-medium hover:bg-blue-700">
                    View Details
                  </button>
                  {voting.status === 'ACTIVE' && (
                    <button className="flex-1 bg-green-600 text-white px-3 py-2 rounded-md text-sm font-medium hover:bg-green-700">
                      Update Results
                    </button>
                  )}
                </div>
              </div>
            )
          })}
      </div>

      {/* Empty State */}
      {votings.filter(voting => {
        if (activeTab === 'active') return voting.status === 'ACTIVE'
        if (activeTab === 'completed') return voting.status === 'COMPLETED'
        return true
      }).length === 0 && (
        <div className="text-center py-12">
          <Vote className="mx-auto h-12 w-12 text-gray-400" />
          <h3 className="mt-2 text-sm font-medium text-gray-900">No votings found</h3>
          <p className="mt-1 text-sm text-gray-500">
            {activeTab === 'active'
              ? 'No active voting processes at the moment'
              : activeTab === 'completed'
              ? 'No completed votings to display'
              : 'Start by creating a new voting process'}
          </p>
          <div className="mt-6">
            <button className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700">
              <Plus className="h-4 w-4 mr-2" />
              Start New Voting
            </button>
          </div>
        </div>
      )}
    </div>
  )
}