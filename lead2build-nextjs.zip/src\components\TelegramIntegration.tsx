'use client'

import { useState, useEffect } from 'react'
import { Send, Users, Settings, MessageCircle, CheckCircle, AlertCircle, Bot, Phone, Zap } from 'lucide-react'
import TelegramAutomation from './TelegramAutomation'

interface TelegramUser {
  id: number
  firstName: string
  lastName?: string
  username?: string
  chatId: number
  role: 'resident' | 'manager' | 'admin'
  address?: string
  leadId?: string
  notifications: boolean
  registeredAt: Date
}

interface BroadcastMessage {
  id: string
  title: string
  message: string
  targetGroup: 'all' | 'residents' | 'managers' | 'specific_address'
  targetAddress?: string
  sentAt: Date
  sentCount: number
  deliveredCount: number
  status: 'sent' | 'pending' | 'failed'
}

export default function TelegramIntegration() {
  const [users, setUsers] = useState<TelegramUser[]>([])
  const [broadcasts, setBroadcasts] = useState<BroadcastMessage[]>([])
  const [activeTab, setActiveTab] = useState<'users' | 'broadcast' | 'settings' | 'templates' | 'automation'>('users')
  const [botToken, setBotToken] = useState('')
  const [botStatus, setBotStatus] = useState<'connected' | 'disconnected' | 'checking'>('disconnected')
  
  // Новое сообщение для рассылки
  const [newMessage, setNewMessage] = useState({
    title: '',
    message: '',
    targetGroup: 'all',
    targetAddress: ''
  })

  // Моковые данные пользователей
  useEffect(() => {
    const mockUsers: TelegramUser[] = [
      {
        id: 1,
        firstName: 'Анна',
        lastName: 'Петрова',
        username: 'anna_petrova',
        chatId: 123456789,
        role: 'resident',
        address: 'ул. Ленина, 15',
        leadId: 'lead-1',
        notifications: true,
        registeredAt: new Date(2025, 8, 15)
      },
      {
        id: 2,
        firstName: 'Иван',
        lastName: 'Сидоров',
        username: 'ivan_sidorov',
        chatId: 987654321,
        role: 'resident',
        address: 'ул. Советская, 22',
        leadId: 'lead-2',
        notifications: true,
        registeredAt: new Date(2025, 8, 18)
      },
      {
        id: 3,
        firstName: 'Мария',
        lastName: 'Управляющая',
        username: 'maria_manager',
        chatId: 555444333,
        role: 'manager',
        notifications: true,
        registeredAt: new Date(2025, 8, 10)
      }
    ]
    setUsers(mockUsers)

    const mockBroadcasts: BroadcastMessage[] = [
      {
        id: '1',
        title: 'Напоминание о голосовании',
        message: 'Завтра состоится голосование по дому ул. Ленина, 15. Время: 18:00',
        targetGroup: 'specific_address',
        targetAddress: 'ул. Ленина, 15',
        sentAt: new Date(2025, 8, 20, 14, 30),
        sentCount: 15,
        deliveredCount: 14,
        status: 'sent'
      },
      {
        id: '2',
        title: 'Системное обновление',
        message: 'Обновлена система отслеживания статусов проектов',
        targetGroup: 'all',
        sentAt: new Date(2025, 8, 19, 10, 0),
        sentCount: 45,
        deliveredCount: 43,
        status: 'sent'
      }
    ]
    setBroadcasts(mockBroadcasts)
  }, [])

  const sendBroadcast = async () => {
    if (!newMessage.title || !newMessage.message) {
      alert('Заполните все поля')
      return
    }

    const broadcast: BroadcastMessage = {
      id: Date.now().toString(),
      title: newMessage.title,
      message: newMessage.message,
      targetGroup: newMessage.targetGroup as any,
      targetAddress: newMessage.targetAddress,
      sentAt: new Date(),
      sentCount: getTargetUsersCount(),
      deliveredCount: 0,
      status: 'sent'
    }

    setBroadcasts([broadcast, ...broadcasts])
    setNewMessage({ title: '', message: '', targetGroup: 'all', targetAddress: '' })
    
    // Имитация доставки
    setTimeout(() => {
      setBroadcasts(prev => 
        prev.map(b => 
          b.id === broadcast.id 
            ? { ...b, deliveredCount: Math.floor(b.sentCount * 0.95) }
            : b
        )
      )
    }, 2000)
  }

  const getTargetUsersCount = () => {
    if (newMessage.targetGroup === 'all') return users.length
    if (newMessage.targetGroup === 'residents') return users.filter(u => u.role === 'resident').length
    if (newMessage.targetGroup === 'managers') return users.filter(u => u.role === 'manager').length
    if (newMessage.targetGroup === 'specific_address') {
      return users.filter(u => u.address === newMessage.targetAddress).length
    }
    return 0
  }

  const testBotConnection = async () => {
    setBotStatus('checking')
    // Имитация проверки подключения
    setTimeout(() => {
      setBotStatus(botToken ? 'connected' : 'disconnected')
    }, 2000)
  }

  const toggleUserNotifications = (userId: number) => {
    setUsers(prev => 
      prev.map(user => 
        user.id === userId 
          ? { ...user, notifications: !user.notifications }
          : user
      )
    )
  }

  const getRoleIcon = (role: TelegramUser['role']) => {
    switch (role) {
      case 'resident': return '🏠'
      case 'manager': return '👔'
      case 'admin': return '⚙️'
      default: return '👤'
    }
  }

  const getRoleLabel = (role: TelegramUser['role']) => {
    switch (role) {
      case 'resident': return 'Жилец'
      case 'manager': return 'Управляющий'
      case 'admin': return 'Администратор'
      default: return 'Пользователь'
    }
  }

  const messageTemplates = [
    {
      id: 'voting_reminder',
      title: 'Напоминание о голосовании',
      template: 'Уважаемые жители! Завтра в {time} состоится голосование по адресу {address}. Тема: {topic}'
    },
    {
      id: 'deadline_warning',
      title: 'Предупреждение о дедлайне',
      template: 'Внимание! До истечения срока {task} остается {days} дней. Адрес: {address}'
    },
    {
      id: 'inspection_complete',
      title: 'Обследование завершено',
      template: 'Техническое обследование по адресу {address} успешно завершено. Результаты: {results}'
    },
    {
      id: 'voting_results',
      title: 'Результаты голосования',
      template: 'Результаты голосования по {address}: ЗА - {yes_votes}, ПРОТИВ - {no_votes}. Решение: {decision}'
    }
  ]

  return (
    <div className="bg-white rounded-lg shadow">
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Bot className="h-6 w-6 text-blue-600" />
            <h2 className="text-xl font-semibold text-gray-900">Telegram Интеграция</h2>
            <div className={`px-2 py-1 text-xs rounded-full ${
              botStatus === 'connected' ? 'bg-green-100 text-green-800' :
              botStatus === 'checking' ? 'bg-yellow-100 text-yellow-800' :
              'bg-red-100 text-red-800'
            }`}>
              {botStatus === 'connected' ? '🟢 Подключен' :
               botStatus === 'checking' ? '🟡 Проверка...' :
               '🔴 Отключен'}
            </div>
          </div>
        </div>

        {/* Навигация */}
        <div className="mt-4 flex space-x-1 bg-gray-100 rounded-lg p-1">
          {[
            { id: 'users', label: 'Пользователи', icon: Users },
            { id: 'broadcast', label: 'Рассылка', icon: Send },
            { id: 'automation', label: 'Автоматизация', icon: Zap },
            { id: 'templates', label: 'Шаблоны', icon: MessageCircle },
            { id: 'settings', label: 'Настройки', icon: Settings }
          ].map(tab => {
            const Icon = tab.icon
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center space-x-2 px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                  activeTab === tab.id 
                    ? 'bg-white text-blue-600 shadow-sm' 
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                <Icon className="h-4 w-4" />
                <span>{tab.label}</span>
              </button>
            )
          })}
        </div>
      </div>

      <div className="p-6">
        {/* Вкладка пользователей */}
        {activeTab === 'users' && (
          <div>
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-medium text-gray-900">
                Зарегистрированные пользователи ({users.length})
              </h3>
              <div className="flex space-x-2 text-sm text-gray-600">
                <span>🏠 Жильцов: {users.filter(u => u.role === 'resident').length}</span>
                <span>👔 Управляющих: {users.filter(u => u.role === 'manager').length}</span>
              </div>
            </div>

            <div className="space-y-4">
              {users.map(user => (
                <div key={user.id} className="border rounded-lg p-4 hover:bg-gray-50">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="text-2xl">{getRoleIcon(user.role)}</div>
                      <div>
                        <h4 className="font-medium text-gray-900">
                          {user.firstName} {user.lastName}
                        </h4>
                        <p className="text-sm text-gray-600">
                          @{user.username} • {getRoleLabel(user.role)}
                        </p>
                        {user.address && (
                          <p className="text-sm text-gray-500">📍 {user.address}</p>
                        )}
                        <p className="text-xs text-gray-400">
                          Зарегистрирован: {user.registeredAt.toLocaleDateString('ru-RU')}
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-3">
                      <label className="flex items-center">
                        <input
                          type="checkbox"
                          checked={user.notifications}
                          onChange={() => toggleUserNotifications(user.id)}
                          className="mr-2"
                        />
                        <span className="text-sm text-gray-600">Уведомления</span>
                      </label>
                      
                      <button className="p-2 text-blue-600 hover:bg-blue-50 rounded-md">
                        <MessageCircle className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Вкладка рассылки */}
        {activeTab === 'broadcast' && (
          <div className="space-y-6">
            {/* Форма новой рассылки */}
            <div className="border rounded-lg p-6 bg-gray-50">
              <h3 className="text-lg font-medium text-gray-900 mb-4">Новая рассылка</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Заголовок
                  </label>
                  <input
                    type="text"
                    value={newMessage.title}
                    onChange={(e) => setNewMessage({...newMessage, title: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
                    placeholder="Введите заголовок сообщения"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Целевая группа
                  </label>
                  <select
                    value={newMessage.targetGroup}
                    onChange={(e) => setNewMessage({...newMessage, targetGroup: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="all">Все пользователи</option>
                    <option value="residents">Только жильцы</option>
                    <option value="managers">Только управляющие</option>
                    <option value="specific_address">Конкретный адрес</option>
                  </select>
                </div>
              </div>

              {newMessage.targetGroup === 'specific_address' && (
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Адрес
                  </label>
                  <input
                    type="text"
                    value={newMessage.targetAddress}
                    onChange={(e) => setNewMessage({...newMessage, targetAddress: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
                    placeholder="Введите адрес"
                  />
                </div>
              )}
              
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Сообщение
                </label>
                <textarea
                  value={newMessage.message}
                  onChange={(e) => setNewMessage({...newMessage, message: e.target.value})}
                  rows={4}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
                  placeholder="Введите текст сообщения"
                />
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">
                  Получателей: {getTargetUsersCount()}
                </span>
                <button
                  onClick={sendBroadcast}
                  className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 flex items-center space-x-2"
                >
                  <Send className="h-4 w-4" />
                  <span>Отправить</span>
                </button>
              </div>
            </div>

            {/* История рассылок */}
            <div>
              <h3 className="text-lg font-medium text-gray-900 mb-4">История рассылок</h3>
              <div className="space-y-3">
                {broadcasts.map(broadcast => (
                  <div key={broadcast.id} className="border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium text-gray-900">{broadcast.title}</h4>
                      <div className="flex items-center space-x-2">
                        <span className={`px-2 py-1 text-xs rounded-full ${
                          broadcast.status === 'sent' ? 'bg-green-100 text-green-800' :
                          broadcast.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                          'bg-red-100 text-red-800'
                        }`}>
                          {broadcast.status === 'sent' ? 'Отправлено' :
                           broadcast.status === 'pending' ? 'В очереди' : 'Ошибка'}
                        </span>
                      </div>
                    </div>
                    
                    <p className="text-sm text-gray-600 mb-3">{broadcast.message}</p>
                    
                    <div className="flex items-center justify-between text-xs text-gray-500">
                      <span>
                        {broadcast.sentAt.toLocaleString('ru-RU')} • 
                        {broadcast.targetGroup === 'all' ? ' Все' :
                         broadcast.targetGroup === 'residents' ? ' Жильцы' :
                         broadcast.targetGroup === 'managers' ? ' Управляющие' :
                         ` ${broadcast.targetAddress}`}
                      </span>
                      <span>
                        Доставлено: {broadcast.deliveredCount}/{broadcast.sentCount}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Вкладка автоматизации */}
        {activeTab === 'automation' && <TelegramAutomation />}

        {/* Вкладка шаблонов */}
        {activeTab === 'templates' && (
          <div>
            <h3 className="text-lg font-medium text-gray-900 mb-6">Шаблоны сообщений</h3>
            <div className="space-y-4">
              {messageTemplates.map(template => (
                <div key={template.id} className="border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium text-gray-900">{template.title}</h4>
                    <button className="text-blue-600 hover:text-blue-800 text-sm">
                      Использовать
                    </button>
                  </div>
                  <p className="text-sm text-gray-600 bg-gray-50 p-3 rounded">
                    {template.template}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Вкладка настроек */}
        {activeTab === 'settings' && (
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-medium text-gray-900 mb-4">Настройки бота</h3>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Telegram Bot Token
                  </label>
                  <div className="flex space-x-2">
                    <input
                      type="password"
                      value={botToken}
                      onChange={(e) => setBotToken(e.target.value)}
                      className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
                      placeholder="Введите токен бота"
                    />
                    <button
                      onClick={testBotConnection}
                      disabled={botStatus === 'checking'}
                      className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 disabled:opacity-50"
                    >
                      {botStatus === 'checking' ? 'Проверка...' : 'Проверить'}
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <label className="flex items-center">
                    <input type="checkbox" defaultChecked className="mr-2" />
                    <span className="text-sm">Автоматические уведомления</span>
                  </label>
                  <label className="flex items-center">
                    <input type="checkbox" defaultChecked className="mr-2" />
                    <span className="text-sm">Напоминания о дедлайнах</span>
                  </label>
                  <label className="flex items-center">
                    <input type="checkbox" defaultChecked className="mr-2" />
                    <span className="text-sm">Уведомления о голосованиях</span>
                  </label>
                  <label className="flex items-center">
                    <input type="checkbox" className="mr-2" />
                    <span className="text-sm">Отчеты о доставке</span>
                  </label>
                </div>
              </div>
            </div>

            <div>
              <h4 className="text-md font-medium text-gray-900 mb-3">Инструкция по настройке</h4>
              <div className="bg-blue-50 p-4 rounded-lg">
                <ol className="text-sm text-gray-700 space-y-2">
                  <li>1. Создайте бота через @BotFather в Telegram</li>
                  <li>2. Получите токен бота и вставьте его выше</li>
                  <li>3. Настройте webhook или используйте polling</li>
                  <li>4. Пользователи смогут регистрироваться через команду /start</li>
                </ol>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}